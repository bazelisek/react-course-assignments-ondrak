export default function HomePage() {
    return (
        <h1>Home page</h1>
    )
}