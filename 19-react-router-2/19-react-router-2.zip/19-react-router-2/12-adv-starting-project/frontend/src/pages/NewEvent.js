export default function NewEventPage() {
    return (
        <h1>New event page</h1>
    )
}