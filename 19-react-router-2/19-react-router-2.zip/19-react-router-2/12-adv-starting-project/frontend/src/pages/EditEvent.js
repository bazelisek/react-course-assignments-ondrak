export default function EditEventPage() {
    return (
        <h1>EditEventPage</h1>
    )
}